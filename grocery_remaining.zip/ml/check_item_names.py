import pandas as pd
import os

def check_item_names():
    bills_path = r"C:\Users\Tejasriseelam\Desktop\grocery_app\data\bills"

    try:
        final_df = pd.read_csv(os.path.join(bills_path, "final_data.csv"))
        merged_df = pd.read_csv(os.path.join(bills_path, "merged_bills.csv"), usecols=['name', 'quantity', 'cost', 'expiry'])
    except FileNotFoundError as e:
        print(f"Error loading files: {e}")
        return

    # Normalize item names for matching
    final_df['Item Name'] = final_df['Item Name'].astype(str).str.strip().str.lower()
    merged_df['name'] = merged_df['name'].astype(str).str.strip().str.lower()

    print("👉 Unique cleaned 'Item Name' values from final_data.csv:")
    print(sorted(final_df['Item Name'].unique()))

    print("\n👉 Unique cleaned 'name' values from merged_bills.csv:")
    print(sorted(merged_df['name'].unique()))

if __name__ == "__main__":
    print("Running item name check...")
    check_item_names()
