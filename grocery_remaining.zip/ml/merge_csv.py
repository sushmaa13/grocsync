import pandas as pd
import os

def create_combined_csv():
    base_path = r"C:\Users\Tejasriseelam\Desktop\grocery_app\data\bills"
    os.makedirs(base_path, exist_ok=True)

    merged_path = os.path.join(base_path, "merged_bills.csv")
    predicted_path = os.path.join(base_path, "predicted_bill.csv")

    # Read merged bills (skip 5th column)
    merged = pd.read_csv(merged_path, usecols=[0, 1, 2, 3], dtype=str)
    merged.columns = ['name', 'quantity', 'cost', 'expiry']
    merged['name'] = merged['name'].str.strip().str.lower()

    # Read predicted bill fully
    predicted = pd.read_csv(predicted_path, dtype=str)

    # Remove TOTAL SAVINGS and SAVINGS rows from predicted to avoid merge issues
    if 'Item Name' in predicted.columns:
        predicted = predicted[~predicted['Item Name'].str.strip().str.lower().isin(['total savings', 'savings'])]

    # Rename columns for merge
    rename_map = {
        'Item Name': 'name',
        'Quantity': 'required_quantity',
        'Status': 'status',
        'Used Quantity': 'used_quantity',
        'Quantity Bought': 'quantity_bought'
    }
    for old_col, new_col in rename_map.items():
        if old_col in predicted.columns:
            predicted.rename(columns={old_col: new_col}, inplace=True)
        else:
            predicted[new_col] = pd.NA

    predicted['name'] = predicted['name'].str.strip().str.lower()

    # Merge dataframes on 'name'
    combined = pd.merge(merged, predicted, on='name', how='outer')

    combined['name'] = combined['name'].str.title()
    combined.dropna(subset=['name'], inplace=True)

    final_columns = ['name', 'quantity', 'cost', 'expiry', 'status', 'used_quantity', 'quantity_bought']
    combined = combined[final_columns]

    combined.to_csv(os.path.join(base_path, 'combined_data.csv'), index=False)
    print("✅ Combined CSV created successfully!")

if __name__ == '__main__':
    create_combined_csv()
