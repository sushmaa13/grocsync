import pandas as pd
import os

def extract_savings():
    base_path = r"C:\Users\Tejasriseelam\Desktop\grocery_app\data\bills"
    os.makedirs(base_path, exist_ok=True)

    predicted_path = os.path.join(base_path, "predicted_bill.csv")

    predicted = pd.read_csv(predicted_path, dtype=str)

    # Find the row where Item Name is "TOTAL SAVINGS" (case insensitive)
    savings_row = predicted[predicted['Item Name'].str.strip().str.lower() == 'total savings']

    if not savings_row.empty:
        # Extract savings amount from "Savings" column
        savings_value = savings_row['Savings'].values[0]
        print(f"✅ Total Savings found: {savings_value}")

        # Save to a separate CSV or just a text file
        savings_df = pd.DataFrame({'Total Savings': [savings_value]})
        savings_df.to_csv(os.path.join(base_path, 'savings.csv'), index=False)
        print("✅ Savings saved to savings.csv")
    else:
        print("⚠️ TOTAL SAVINGS row not found in predicted_bill.csv")

if __name__ == '__main__':
    extract_savings()
