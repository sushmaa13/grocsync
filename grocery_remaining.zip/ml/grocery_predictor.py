import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import os

def load_and_prepare_data():
    bills_path = r"C:\Users\Tejasriseelam\Desktop\grocery_app\data\bills"

    try:
        final_df = pd.read_csv(os.path.join(bills_path, "final_data.csv"))
        # Only read first 4 columns, ignore freshness
        merged_df = pd.read_csv(os.path.join(bills_path, "merged_bills.csv"), usecols=['name', 'quantity', 'cost', 'expiry'])
    except FileNotFoundError as e:
        print(f"Error loading files: {e}")
        return None, None

    # Normalize item names: strip and lowercase
    final_df['Item Name'] = final_df['Item Name'].astype(str).str.strip().str.lower()
    merged_df['name'] = merged_df['name'].astype(str).str.strip().str.lower()

    print("Merging datasets on normalized item names...")

    # Merge dataframes on normalized item names
    df = pd.merge(final_df, merged_df, left_on='Item Name', right_on='name', how='inner')

    if df.empty:
        print("Error: No matching items found between final_data.csv and merged_bills.csv.")
        return None, None

    print(f"Merged dataframe shape: {df.shape}")

    # Drop columns not needed for model
    df = df.drop(columns=['Quantity', 'name', 'expiry'])

    # Rename columns for easier handling
    df = df.rename(columns={
        'Quantity Bought': 'quantity_bought',
        'Used Quantity': 'used_quantity',
        'cost': 'cost_per_unit'
    })

    # Fill missing used_quantity values
    df['used_quantity'] = df['used_quantity'].fillna(0)

    # Encode 'Status' column as numeric
    df['status'] = df['Status'].map({
        'Used': 2,
        'Partially Used': 1,
        'Expired': 0
    }).fillna(0)

    # Drop original Status column
    df = df.drop(columns=['Status'])

    print("Prepared dataframe preview:")
    print(df.head())

    return df, bills_path

def train_model(df):
    # Features and target, now including used_quantity as feature
    X = df[['quantity_bought', 'used_quantity', 'status', 'cost_per_unit']]
    y = df['used_quantity']

    if X.empty or y.empty:
        print("Error: Not enough data to train.")
        return None

    # Split into train/test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train RandomForest model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Evaluate model
    y_pred = model.predict(X_test)
    print(f"Model Evaluation - MSE: {mean_squared_error(y_test, y_pred):.2f}, R²: {r2_score(y_test, y_pred):.2f}")

    return model

def predict_and_save(model, df, bills_path):
    # Include used_quantity in prediction features
    X = df[['quantity_bought', 'used_quantity', 'status', 'cost_per_unit']]
    df['predicted_quantity'] = model.predict(X).round().astype(int)

    # Calculate savings as (quantity bought - predicted quantity) * cost per unit
    df['savings'] = (df['quantity_bought'] - df['predicted_quantity']) * df['cost_per_unit']

    # Calculate total savings
    total_savings = df['savings'].sum()

    # Calculate estimated cost (predicted_quantity * cost per unit)
    df['estimated_cost'] = df['predicted_quantity'] * df['cost_per_unit']

    # Prepare result dataframe with user-friendly column names and correct column order
    result = df[['Item Name', 'quantity_bought', 'used_quantity', 'predicted_quantity', 'cost_per_unit', 'savings', 'estimated_cost']].rename(columns={
         'Item Name': 'Item Name',
        'quantity_bought': 'Quantity Bought',
        'used_quantity': 'Used Quantity',
        'predicted_quantity': 'Required Quantity',
        'cost_per_unit': 'Cost Per Unit',
        'savings': 'Savings',
        'estimated_cost': 'Total Cost'
    })

    # Append a summary row for total savings
    summary = pd.DataFrame({
        'Item Name': ['TOTAL SAVINGS'],
        'Quantity Bought': [''],
        'Used Quantity':[''],
        'Required Quantity': [''],
        'Cost Per Unit': [''],
        'Savings': [total_savings],
        'Total Cost': ['']
    })

    result_with_total = pd.concat([result, summary], ignore_index=True)

    save_path = os.path.join(bills_path, "predicted_bill.csv")
    result_with_total.to_csv(save_path, index=False)

    print(f"✅ Prediction saved to {save_path}")
    print(f"Total Savings: {total_savings:.2f}")

    return result_with_total

def main():
    df, bills_path = load_and_prepare_data()
    if df is not None:
        model = train_model(df)
        if model:
            predict_and_save(model, df, bills_path)

if __name__ == "__main__":
    main()
