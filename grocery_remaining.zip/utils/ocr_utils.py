import pytesseract
from PIL import Image
import cv2
import re
from datetime import datetime, timedelta

def extract_text(image_path):
    image = Image.open(image_path)
    return pytesseract.image_to_string(image)


def parse_items(text):
    lines = text.strip().split("\n")
    items = []

    date_pattern = r'\b\d{4}-\d{2}-\d{2}\b'  # Matches YYYY-MM-DD

    for line in lines:
        line = line.strip()
        if not line or any(skip in line.lower() for skip in ['date', 'total', 'cashier', 'qty', 'thank']):
            continue

        date_match = re.search(date_pattern, line)
        expiry_date = date_match.group(0) if date_match else None
        if expiry_date:
            line = line.replace(expiry_date, '').strip()

        numbers = re.findall(r'\d+\.\d+|\d+', line)
        if len(numbers) < 2:
            continue  # Need at least quantity & price

        try:
            price = float(numbers[-1])
            quantity = int(numbers[-2])
        except:
            continue

        name_match = re.match(r'(.+?)\s+\d+\s+[\d\.]+', line)
        item_name = name_match.group(1).strip() if name_match else line

        # Determine expiry status
        status = 'fresh'
        if expiry_date:
            expiry_date_obj = datetime.strptime(expiry_date, '%Y-%m-%d')
            today = datetime.today()

            if expiry_date_obj < today:
                status = 'expired'
            elif expiry_date_obj <= today + timedelta(days=3):
                status = 'about to expire'

        items.append({
            'name': item_name,
            'quantity': quantity,
            'cost': price,
            'expiry': expiry_date,
            'status': status  # Add expiry status
        })

    return items
